import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marks-chart',
  templateUrl: './marks-chart.component.html',
  styleUrls: ['./marks-chart.component.css']
})
export class MarksChartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
