import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-student-form',
  templateUrl: './student-form.component.html',
  styleUrls: ['./student-form.component.css']
})
export class StudentFormComponent {
  constructor(private fb: FormBuilder ){}
  studentValue = this.fb.group({
    name : [''],
    AI : [''],
    Python : [''],
    Maths : [''],
    Angular: ['']
  });
  ngOnInit(){
    console.log("hani");
    console.log("value", this.studentValue.value)
  }
  onSubmit(){
    console.log("hani hii")
    console.log("value", this.studentValue.value);
    
  }
}
